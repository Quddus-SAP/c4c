sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("qs.c4c.controller.App", {
        onInit() {
        }
      });
    }
  );
  