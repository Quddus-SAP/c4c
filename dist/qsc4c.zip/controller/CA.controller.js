sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("qs.c4c.controller.CA",{onInit:function(){}})});
//# sourceMappingURL=CA.controller.js.map